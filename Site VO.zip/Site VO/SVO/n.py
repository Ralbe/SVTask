print(hex(hash("kiri"))[3:])
print(hex(hash("kiri"))[3:])
print(hex(hash("kiri"))[3:])